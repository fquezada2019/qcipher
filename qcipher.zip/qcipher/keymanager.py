'''
    Filename      : keymanager.py
    Date Created  : 20/01/2018
    Last Modified : 25/05/2018
    Author        : Felipe Quezada V.

    *** ***
'''
import json
import os

class KeyMgr:
  @staticmethod
  def key_generator(length=32):
    if isinstance(length,int) and os.path.isfile('qcipher/matdic.json') and os.stat("qcipher/matdic.json").st_size != 0:
      import random
      from .q1 import QUni
      #choice a random range
      rangos = []
      result = []
      output = ''
      #open a dicctionary
      with open('qcipher/matdic.json') as json_file:  
        rangos = json.load(json_file)
      cont = 0
      while cont < length:
        random.shuffle(rangos)
        temp = random.choice(rangos)
        if temp not in result:
          rangos.remove(temp)
          result.append(temp)
          cont = cont + 1
      #if all is ok
      if len(result) == length:
        for x in range(len(result)):
          obj = QUni(result[x][2],result[x][3],True)
          #ahora random
          caracter = ''
          sec = random.choice(result[x][1])
          if sec.lower() == 'all':
            sec = ' '
          if len(obj.get_uni_characters(sec)) > 0:
            caracter = random.choice(obj.get_uni_characters(sec))
          else:
            caracter = '#'
          output = output+caracter
          del obj
      else:
        output = False
      return output
    else:
      return False

  def set_key(self, length=32):
    if isinstance(length, int) and self.key_generator() is not False:
      works = False
      import base64
      #Check if global.json exist
      if os.path.isfile('qcipher/global.json'):
        with open('qcipher/global.json','r') as json_file:
          data = json.load(json_file)
        if len(data) > 0 and type(data) is list:
          #Check if valid
          valid = True
          for x in data:
            if isinstance(x, dict) and len(x) == 2:
              if 'id_key' not in x or 'key' not in x:
                valid = False
                break
            else:
              valid = False
              break
          if valid:
            #find the last position and obtain the key
            key = { "id_key": len(data)+1, "key": base64.b64encode(self.key_generator().encode()).decode() }
            data.append(key.copy())
            #Create a json file with data
            with open('qcipher/global.json','w') as json_file:
              json.dump(data, json_file, indent=2)
            works = True
      else:
        #Key generator, with a file
        data = []
        key = { "id_key":1, "key": base64.b64encode(self.key_generator().encode()).decode() }
        data.append(key.copy())
        #Create a json file with data
        with open('qcipher/global.json','w') as json_file:
          json.dump(data, json_file, indent=2)
        works = True
      return works
    else:
      return False
  
  @staticmethod
  def get_key(id='random'):
    #Check if global.json exist
    if os.path.isfile('qcipher/global.json') and os.stat("qcipher/global.json").st_size != 0:
      with open('qcipher/global.json','r') as json_file:
        data = json.load(json_file)
      if len(data) > 0 and type(data) is list:
        result = {}
        if id == 'random':
          import random
          data = random.choice(data)
          if isinstance(data, dict):
            if 'id_key' and 'key' in data:
              result = data
        elif isinstance(id, int):
          #Loop the list with value (each position is a dict)  
          for x in data:
            if isinstance(x, dict):
              if 'id_key' and 'key' in x:
                if x['id_key'] == id:
                  result = x
                  break
            else:
              break
        return result
      else:
        return False
    else:
      return False
              
