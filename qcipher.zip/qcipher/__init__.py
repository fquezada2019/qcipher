'''
   Filename     : __init__.py
   Date Created : 29/01/2018
   Last Modified: 02/03/2018
   Autor        : Felipe Quezada V.
'''
import json
import os

class QCipher:

  @staticmethod
  def is_hexa(text):
    try:
      int(text, 16)
      return True
    except (ValueError, TypeError):
      return False

  @staticmethod
  def listint(s):
    if type(s) is list and len(s) > 0:
      for x in s:
        if isinstance(x, int) is False:
          return False
      return True
    else:
      return False

  @staticmethod  
  def get_md5(text):
    import hashlib
    text = str(text)
    h = hashlib.md5()
    h.update(text.encode())
    return h.hexdigest()

  @staticmethod
  def chr_hexa(character):
    if isinstance(character, int):
      #Get value
      tmp = hex(character)
      #Remove 0x
      tmp = tmp[2:]
      #Set empty 
      string_f = ''
      #Changing
      for s in tmp:
        if s == '0':
          string_f = string_f+'a'
        if s == '1':
          string_f = string_f+'b'
        if s == '2':
          string_f = string_f+'c'
        if s == '3':
          string_f = string_f+'d'
        if s == '4':
          string_f = string_f+'e'
        if s == '5':
          string_f = string_f+'f'
        if s == '6':
          string_f = string_f+str(s)
        if s == '7':
          string_f = string_f+str(s)
        if s == '8':
          string_f = string_f+str(s)
        if s == '9':
          string_f = string_f+str(s)
        if s == 'a':
          string_f = string_f+'0'
        if s == 'b':
          string_f = string_f+'1'
        if s == 'c':
          string_f = string_f+'2'
        if s == 'd':
          string_f = string_f+'3'
        if s == 'e':
          string_f = string_f+'4'
        if s == 'f':
          string_f = string_f+'5'
      tapados = ''
      if len(string_f)%3 == 0:
        tapados = string_f[::-1]
      else:
        i = 0
        while i < len(string_f):
          tapados = tapados+string_f[i:i+2][::-1]
          i = i+2
      return tapados
    else:
      return False
  
  def hexa_chr(self,hexas,printable=False):
    if self.is_hexa(hexas):
      #Set empty 
      string_f = ''
      for s in hexas:
        if s == '0':
          string_f = string_f+'a'
        if s == '1':
          string_f = string_f+'b'
        if s == '2':
          string_f = string_f+'c'
        if s == '3':
          string_f = string_f+'d'
        if s == '4':
          string_f = string_f+'e'
        if s == '5':
          string_f = string_f+'f'
        if s == '6':
          string_f = string_f+s
        if s == '7':
          string_f = string_f+s
        if s == '8':
          string_f = string_f+s
        if s == '9':
          string_f = string_f+s
        if s.lower() == 'a':
          string_f = string_f+'0'
        if s.lower() == 'b':
          string_f = string_f+'1'
        if s.lower() == 'c':
          string_f = string_f+'2'
        if s.lower() == 'd':
          string_f = string_f+'3'
        if s.lower() == 'e':
          string_f = string_f+'4'
        if s.lower() == 'f':
          string_f = string_f+'5'
      tapados = ''
      if len(string_f)%3 == 0:
        tapados = string_f[::-1]
      else:
        i = 0
        while i < len(string_f):
          tapados = tapados+string_f[i:i+2][::-1]
          i = i+2
      if printable is True:
        tapados = chr(int(tapados, 16))
      return tapados
    else:
      return False

  def get_map(self,entrada):
    if os.path.isfile('qcipher/matdic.json') and os.stat("qcipher/matdic.json").st_size != 0:
      import random
      from .q1 import QUni
      #para diccionario
      conversion = list(set(entrada))
      rangos = []
      result = []
      final = []
      #read
      with open('qcipher/matdic.json') as json_file:  
        rangos = json.load(json_file)
      cont = 0
      while cont < len(conversion):
        random.shuffle(rangos)
        temp = random.choice(rangos)
        if temp not in result:
          rangos.remove(temp)
          result.append(temp)
          cont = cont + 1
    
      for x in range(len(result)):
        obj = QUni(result[x][2],result[x][3],True)
        caracter = ''
        aux = []
        pos = []
        #ahora random
        sec = random.choice(result[x][1])
        if sec.lower() == 'all':
          sec = ' '
        if len(obj.get_uni_characters(sec)) > 0:
          caracter = random.choice(obj.get_uni_characters(sec))
          caracter = self.chr_hexa(ord(caracter))
        else:
          caracter = conversion[x]
        #del obj
        del obj
        aux.append(self.chr_hexa(ord(conversion[x])))
        aux.append(caracter)
        #Se recorre la entrada
        for z in range(len(entrada)):
          if conversion[x] == entrada[z]:
            pos.append(z)
        #Se agrega pos al array
        aux.append(pos)
        final.append(aux)
      return final
    else:
      return False
  
  def check_map(self,e):
    if type(e) is list and len(e) > 0:
      for x in e:
        #simulate a switch
        if type(x) is not list or self.listint(x[2]) is False:
          return False
        if len(x) != 3 or self.hexa_chr(x[0]) is False or self.hexa_chr(x[1]) is False:
          return False
      return True  
    else:
      return False
  
  def encode_q(self,source):
    #check if getmap is true and other...
    from .keymanager import KeyMgr
    if self.get_map(str(source)) is not False and KeyMgr().get_key() is not False:
      import base64
      from .aespy import AESCipher
      from .encryptor import Mtk
      #Obtain a map
      #Output
      output = {}
      map = self.get_map(str(source))
      output["key"] = ''
      for x in map:
        output["key"] = output["key"]+self.hexa_chr(x[1],True)
      #save key_parity
      output["key"] = self.get_md5(output["key"])
      #get a random key
      key = KeyMgr().get_key()
      #using AES
      cipher = AESCipher(base64.b64decode(key["key"].encode()).decode())
      encrypted = cipher.encrypt(json.dumps(map))
      #Encode to MDE Mode
      output["encrypt"] = Mtk().encryptor(encrypted)+':'+str(key["id_key"])
      return output
    else:
      return False
  
  def decode_q(self, encrypted):
    if type(encrypted) is dict and 'encrypt' in encrypted and 'key' in encrypted:
      if len(str(encrypted['encrypt']).split(':')) == 2:
        #Next Check
        from .encryptor import Mtk
        temp = encrypted['encrypt'].split(':')
        if Mtk().decryptor(temp[0]) is not False:
          import base64
          try:
            from .aespy import AESCipher
            from .keymanager import KeyMgr
            new_cipher = AESCipher(base64.b64decode(KeyMgr().get_key(int(temp[1]))['key'].encode()).decode())
            decrypted = new_cipher.decrypt(Mtk().decryptor(temp[0]))
            map = json.loads(decrypted)
            if self.check_map(map):
              #Fix quotes
              check_source = ''
              for x in map:
                check_source = check_source+self.hexa_chr(x[1],True)
              #Check if key is correct
              if self.get_md5(check_source) == encrypted['key']:
                #Obtener la posicion mayor
                cont_temp = 0
                for x in map:
                  for y in x[2]:
                    if y > cont_temp:
                      cont_temp = y
                #Preparar plantilla
                str_temp = []
                #crear plantilla segun cantidad
                for x in range(cont_temp+1):
                  str_temp.append(chr(24))
                #Se vuelve a caracteres originales
                for x in map:
                  for y in x[2]:
                    str_temp[y] = self.hexa_chr(x[0],True)
                #Check if all its ok
                if chr(24) not in str_temp:
                  return ''.join((str(w) for w in str_temp))
                else:
                  return False
              else:
                return False
            else:
              return False    
          except (UnicodeError, ValueError, ImportError, IndexError):
            return False
        else:
          return False
      else:
        return False
    else:
      return False  

