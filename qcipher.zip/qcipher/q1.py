'''
    Filename      : q1.py
    Date Created  : 6/06/2017
    Last Modified : 19/02/2018
    Author        : Felipe Quezada V.

    *** ***
'''
import unicodedata

class QUni:
 def __init__(self,start,end,printable=False):
    self.start = int(start)
    self.end = int(end)
    self.printable = printable

 #GET a string from a range of Unicode
 def get_uni_characters(self,cont='letter',not_cont=''):
   characters = []
   for n in range(self.start,self.end):
     c = chr(n)
     try:
        id =  unicodedata.name(c).lower()
        if not_cont == '':
          if cont.lower() in id:
           if self.printable is True:
             characters.append(c)
           else:
             characters.append(ord(c))
        else:
          if cont.lower() in id and not not_cont.lower() in id:
           if self.printable is True:
             characters.append(c)
           else:
             characters.append(ord(c))
     except ValueError:
        pass
   return characters

 #GET a dictionary from a range of Unicode
 def __get_uni_dict(self,cont='letter',not_cont=''):
   characters = {}
   for n in range(self.start,self.end):
     c = chr(n)
     try:
        id =  unicodedata.name(c).lower()
        if not_cont == '':
          if cont.lower() in id:
           if self.printable is True:
             characters[c] = id
           else:
             characters[ord(c)] = id
        else:
          if cont.lower() in id and not not_cont.lower() in id:
           if self.printable is True:
             characters[c] = id
           else:
             characters[ord(c)] = id
     except ValueError:
        pass
   if characters is False:
      characters = ''
   return characters

