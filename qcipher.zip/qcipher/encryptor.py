class Mtk:
  @staticmethod
  def is_hexa(text):
    try:
      int(text, 16)
      return True
    except (ValueError, TypeError):
      return False
  @staticmethod
  def __inv_couple(s):
    conver = s
    if len(conver)%2 == 0:
      corregido = ''
      cont = 0
      while cont < len(conver):
        temp = conver[cont:cont+2]
        if temp[0] not in '/=_-+' and temp[1] not in '/=_-+':
          temp = temp[::-1]
        corregido = corregido+temp
        cont = cont+2
      conver = corregido
    else:
      conver = conver[::-1]
    return conver

  @staticmethod
  def chr_hexa(character):
    if isinstance(character, int):
      #Get value
      tmp = hex(character)
      #Remove 0x
      tmp = tmp[2:]
      #Set empty 
      string_f = ''
      #Changing
      for s in tmp:
        if s == '0':
          string_f = string_f+'a'
        if s == '1':
          string_f = string_f+'b'
        if s == '2':
          string_f = string_f+'c'
        if s == '3':
          string_f = string_f+'d'
        if s == '4':
          string_f = string_f+'e'
        if s == '5':
          string_f = string_f+'f'
        if s == '6':
          string_f = string_f+str(s)
        if s == '7':
          string_f = string_f+str(s)
        if s == '8':
          string_f = string_f+str(s)
        if s == '9':
          string_f = string_f+str(s)
        if s == 'a':
          string_f = string_f+'0'
        if s == 'b':
          string_f = string_f+'1'
        if s == 'c':
          string_f = string_f+'2'
        if s == 'd':
          string_f = string_f+'3'
        if s == 'e':
          string_f = string_f+'4'
        if s == 'f':
          string_f = string_f+'5'
      tapados = ''
      if len(string_f)%3 == 0:
        tapados = string_f[::-1]
      else:
        i = 0
        while i < len(string_f):
          tapados = tapados+string_f[i:i+2][::-1]
          i = i+2
      return tapados
    else:
      return False

  @staticmethod
  def str_to_hexa(text):
    import binascii
    return binascii.b2a_hex(str(text).encode())
  
  def hexa_to_str(self,encoded):
    if self.is_hexa(encoded):
      import binascii
      return binascii.a2b_hex(encoded)
    else:
      return False


  def hexa_chr(self,hexas,printable=False):
    if self.is_hexa(hexas):
      #Set empty 
      string_f = ''
      for s in hexas:
        if s == '0':
          string_f = string_f+'a'
        if s == '1':
          string_f = string_f+'b'
        if s == '2':
          string_f = string_f+'c'
        if s == '3':
          string_f = string_f+'d'
        if s == '4':
          string_f = string_f+'e'
        if s == '5':
          string_f = string_f+'f'
        if s == '6':
          string_f = string_f+s
        if s == '7':
          string_f = string_f+s
        if s == '8':
          string_f = string_f+s
        if s == '9':
          string_f = string_f+s
        if s.lower() == 'a':
          string_f = string_f+'0'
        if s.lower() == 'b':
          string_f = string_f+'1'
        if s.lower() == 'c':
          string_f = string_f+'2'
        if s.lower() == 'd':
          string_f = string_f+'3'
        if s.lower() == 'e':
          string_f = string_f+'4'
        if s.lower() == 'f':
          string_f = string_f+'5'
      tapados = ''
      if len(string_f)%3 == 0:
        tapados = string_f[::-1]
      else:
        i = 0
        while i < len(string_f):
          tapados = tapados+string_f[i:i+2][::-1]
          i = i+2
      if printable is True:
        tapados = chr(int(tapados, 16))
      return tapados
    else:
      return False

  def encryptor(self,text):
    try:
      text = str(text)
      acum = ''
      for x in text:
        #convert to hexa
        temp = self.chr_hexa(ord(x))
        #Invert
        temp = self.__inv_couple(temp)
        #add to string
        acum = acum+temp+":"
      #remove the last
      acum = acum[:len(acum)-1]
      return self.str_to_hexa(acum).decode()
    except Exception:
      return False

  def decryptor(self,encoded):
    try:
      text = str(encoded)
      acum = ''
      #Decode Hexa
      text = self.hexa_to_str(text).decode()
      text = text.split(":")
      if len(text) > 0:
        for x in text:
          #Invert
          temp = self.__inv_couple(x)
          #hexa to chr
          temp = self.hexa_chr(temp,True)
          #add to string
          acum = acum+temp
        return acum
      return False
    except Exception:
      return False  

